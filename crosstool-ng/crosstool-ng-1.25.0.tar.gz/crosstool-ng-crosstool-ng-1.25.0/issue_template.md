### Issue submission guidelines
See [detaled guidelines](http://crosstool-ng.github.io/support/). In short:
- Report crosstool-NG version
- Report host OS and its version
- Attach `.config` (unless the issue is not related to any configuration)
- Attach `build.log` (unless crosstool-NG fails before the build starts)
